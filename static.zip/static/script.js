// Wildfire Risk Predictor JavaScript

// Global variables
let map;
let currentMarker;
let loadingModal;

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    initializeMap();
    initializeChat();
    checkSystemStatus();
    
    // Initialize Bootstrap modal
    loadingModal = new bootstrap.Modal(document.getElementById('loadingModal'), {
        keyboard: false,
        backdrop: 'static'
    });
});

// Initialize Leaflet map
function initializeMap() {
    // Create map centered on USA
    map = L.map('map').setView([39.8283, -98.5795], 4);
    
    // Add OpenStreetMap tiles
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors',
        maxZoom: 18
    }).addTo(map);
    
    // Add click event listener
    map.on('click', function(e) {
        handleMapClick(e.latlng.lat, e.latlng.lng);
    });
    
    console.log('Map initialized successfully');
}

// Handle map click events
async function handleMapClick(lat, lng) {
    // Show loading modal
    loadingModal.show();
    
    // Remove existing marker
    if (currentMarker) {
        map.removeLayer(currentMarker);
    }
    
    try {
        // Make prediction request
        const response = await fetch('/api/predict', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                latitude: lat,
                longitude: lng
            })
        });
        
        const data = await response.json();
        
        if (data.status === 'success') {
            // Add marker to map
            addRiskMarker(lat, lng, data);
            
            // Update UI with results
            updatePredictionResults(data);
            updateWeatherInfo(data.weather);
            
            // Show results panel
            document.getElementById('prediction-results').style.display = 'block';
        } else {
            showAlert('Error getting prediction: ' + data.error, 'danger');
        }
        
    } catch (error) {
        console.error('Prediction error:', error);
        showAlert('Error connecting to prediction service', 'danger');
    } finally {
        // Hide loading modal
        loadingModal.hide();
    }
}

// Add risk marker to map
function addRiskMarker(lat, lng, data) {
    const predictions = data.predictions;
    
    // Calculate average risk level
    let avgRisk = 0;
    let count = 0;
    
    for (const [key, value] of Object.entries(predictions)) {
        avgRisk += value;
        count++;
    }
    avgRisk = count > 0 ? avgRisk / count : 0;
    
    // Determine risk level and color
    let riskLevel, color;
    if (avgRisk < 0.25) {
        riskLevel = 'Low';
        color = '#28a745';
    } else if (avgRisk < 0.5) {
        riskLevel = 'Moderate';
        color = '#ffc107';
    } else if (avgRisk < 0.75) {
        riskLevel = 'High';
        color = '#fd7e14';
    } else {
        riskLevel = 'Extreme';
        color = '#dc3545';
    }
    
    // Create custom icon
    const riskIcon = L.divIcon({
        className: 'risk-marker',
        html: `<div style="background-color: ${color}; width: 20px; height: 20px; border-radius: 50%; border: 3px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3);"></div>`,
        iconSize: [26, 26],
        iconAnchor: [13, 13]
    });
    
    // Create popup content
    const popupContent = `
        <div class="popup-title">🔥 Wildfire Risk Assessment</div>
        <div class="popup-info"><strong>Location:</strong> ${lat.toFixed(4)}, ${lng.toFixed(4)}</div>
        <div class="popup-info"><strong>Risk Level:</strong> ${riskLevel}</div>
        <div class="popup-info"><strong>Average Risk:</strong> ${(avgRisk * 100).toFixed(1)}%</div>
        ${data.weather ? `<div class="popup-info"><strong>Temperature:</strong> ${data.weather.temperature}°F</div>` : ''}
    `;
    
    // Add marker to map
    currentMarker = L.marker([lat, lng], { icon: riskIcon })
        .addTo(map)
        .bindPopup(popupContent)
        .openPopup();
}

// Update prediction results panel
function updatePredictionResults(data) {
    const { predictions, location } = data;
    
    // Update location info
    document.getElementById('location-info').textContent = 
        `Latitude: ${location.latitude.toFixed(4)}, Longitude: ${location.longitude.toFixed(4)}`;
    
    // Update individual risk predictions
    updateRiskBar('ultimate-risk', predictions.ultimate_risk || 0);
    updateRiskBar('general-risk', predictions.risk || 0);
    updateRiskBar('cause-risk', predictions.cause || 0);
}

// Update individual risk bar
function updateRiskBar(barId, value) {
    const percentage = Math.round(value * 100);
    const bar = document.getElementById(`${barId}-bar`);
    const text = document.getElementById(`${barId}-text`);
    
    // Update progress bar
    bar.style.width = `${percentage}%`;
    bar.textContent = `${percentage}%`;
    text.textContent = `${percentage}%`;
    
    // Update color based on risk level
    bar.className = 'progress-bar';
    if (percentage < 25) {
        bar.classList.add('risk-low');
    } else if (percentage < 50) {
        bar.classList.add('risk-moderate');
    } else if (percentage < 75) {
        bar.classList.add('risk-high');
    } else {
        bar.classList.add('risk-extreme');
    }
}

// Update weather information
function updateWeatherInfo(weather) {
    if (!weather) return;
    
    document.getElementById('temperature').textContent = weather.temperature;
    document.getElementById('humidity').textContent = weather.humidity;
    document.getElementById('wind-speed').textContent = weather.wind_speed;
    document.getElementById('weather-desc').textContent = weather.description;
    
    // Update current weather panel
    const currentWeatherDiv = document.getElementById('current-weather');
    currentWeatherDiv.innerHTML = `
        <div class="weather-item">
            <span>🌡️ Temperature:</span>
            <span class="weather-value">${weather.temperature}°F</span>
        </div>
        <div class="weather-item">
            <span>💧 Humidity:</span>
            <span class="weather-value">${weather.humidity}%</span>
        </div>
        <div class="weather-item">
            <span>💨 Wind Speed:</span>
            <span class="weather-value">${weather.wind_speed} mph</span>
        </div>
        <div class="weather-item">
            <span>☁️ Conditions:</span>
            <span class="weather-value">${weather.description}</span>
        </div>
    `;
}

// Initialize chat functionality
function initializeChat() {
    const chatInput = document.getElementById('chat-input');
    const sendButton = document.getElementById('send-chat');
    
    // Send message on button click
    sendButton.addEventListener('click', sendChatMessage);
    
    // Send message on Enter key
    chatInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            sendChatMessage();
        }
    });
}

// Send chat message
async function sendChatMessage() {
    const input = document.getElementById('chat-input');
    const message = input.value.trim();
    
    if (!message) return;
    
    // Clear input
    input.value = '';
    
    // Add user message to chat
    addChatMessage(message, 'user');
    
    try {
        // Send to backend
        const response = await fetch('/api/chat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ question: message })
        });
        
        const data = await response.json();
        
        if (data.status === 'success') {
            // Add bot response
            addChatMessage(data.response, 'bot');
        } else {
            addChatMessage('Sorry, I encountered an error. Please try again.', 'bot');
        }
        
    } catch (error) {
        console.error('Chat error:', error);
        addChatMessage('Sorry, I cannot connect to the chat service right now.', 'bot');
    }
}

// Add message to chat
function addChatMessage(message, sender) {
    const chatMessages = document.getElementById('chat-messages');
    const messageDiv = document.createElement('div');
    
    const timestamp = new Date().toLocaleTimeString();
    const icon = sender === 'user' ? '👤' : '🤖';
    
    messageDiv.className = `chat-message chat-${sender}`;
    messageDiv.innerHTML = `
        ${icon} ${message}
        <div class="chat-timestamp">${timestamp}</div>
    `;
    
    chatMessages.appendChild(messageDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

// Check system status
async function checkSystemStatus() {
    try {
        const response = await fetch('/api/status');
        const data = await response.json();
        
        updateSystemStatus(data);
        updateStatusIndicator('online');
        
    } catch (error) {
        console.error('Status check error:', error);
        updateStatusIndicator('offline');
    }
}

// Update system status display
function updateSystemStatus(data) {
    const statusDiv = document.getElementById('system-status');
    const models = data.models;
    
    let statusHTML = '<h6>📊 Model Status:</h6>';
    
    for (const [modelName, status] of Object.entries(models)) {
        const icon = status === 'loaded' ? '✅' : '❌';
        const statusText = status === 'loaded' ? 'Loaded' : 'Failed';
        statusHTML += `<p>${icon} ${modelName.replace('_', ' ').toUpperCase()}: ${statusText}</p>`;
    }
    
    statusHTML += `<small class="text-muted">Last updated: ${new Date().toLocaleTimeString()}</small>`;
    statusDiv.innerHTML = statusHTML;
}

// Update status indicator in navbar
function updateStatusIndicator(status) {
    const indicator = document.getElementById('status-indicator');
    
    indicator.className = 'navbar-text';
    
    if (status === 'online') {
        indicator.innerHTML = 'System Status: <span class="status-online">●</span> Online';
    } else if (status === 'offline') {
        indicator.innerHTML = 'System Status: <span class="status-offline">●</span> Offline';
    } else {
        indicator.innerHTML = 'System Status: <span class="status-loading">●</span> Loading...';
    }
}

// Show alert message
function showAlert(message, type = 'info') {
    const alertHTML = `
        <div class="alert alert-${type} alert-dismissible fade show" role="alert">
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    
    // Add to top of main content
    const container = document.querySelector('.container-fluid');
    const tempDiv = document.createElement('div');
    tempDiv.innerHTML = alertHTML;
    container.insertBefore(tempDiv.firstElementChild, container.firstElementChild);
    
    // Auto-dismiss after 5 seconds
    setTimeout(() => {
        const alert = document.querySelector('.alert');
        if (alert) {
            alert.remove();
        }
    }, 5000);
}

// Utility function to format numbers
function formatNumber(num, decimals = 2) {
    return parseFloat(num).toFixed(decimals);
}

// Utility function to get risk level text
function getRiskLevelText(value) {
    if (value < 0.25) return 'Low';
    if (value < 0.5) return 'Moderate';
    if (value < 0.75) return 'High';
    return 'Extreme';
}

console.log('Wildfire Risk Predictor initialized successfully');